export function Table() {
  return (
    <svg
      fill="#fff"
      stroke="#fff"
      viewBox="0 0 50 50"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path d="M10.586 11l-10 10h48.828l-10-10H10.586zM0 22v6h50v-6H0zm3 7v21h6V29H3zm8 0v14h6V29h-6zm22 0v14h6V29h-6zm8 0v21h6V29h-6z" />
    </svg>
  );
}
